1. Wipe the data in the console.
	adb shell wipe data
2. Flash the bootloader using the JLink cable

3. Copy the IO file into the console under the path /sdcard and rename it as ROM.bin
	adb push Black_Widow_IO_ROM.bin /sdcard/ROM.bin

4. Install the EBWhite_Hardware_TestApp.apk

5. Open the app: Hardware Test APP 

6. Go to IO menu from the left navigation bar

7. Select IO Update from the central pane (the item is in the second row, third column)

8. If you successfully completed step 2 and step 3 then press the Update button, you should see a toast msg saying entered LCB update mode.
	Wait for 20 seconds, and then you will see another toast message saying update completed successfully.